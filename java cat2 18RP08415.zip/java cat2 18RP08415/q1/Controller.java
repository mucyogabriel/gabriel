/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
public class Controller
{
	Car d;
	Wheel t;
	Engine w;
	public void display(Car d,Wheel t,Engine w )
	{
		this.d=d;
		this.t=t;
		this.w=w;
	}
	public static void main(String[] args) {
		Car obj1=new Car();
		
		Wheel obj2=new Wheel();
		Engine obj3=new Engine();
		


;
		
	}
}