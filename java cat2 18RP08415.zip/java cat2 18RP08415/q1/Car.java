/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
public class Car
{

	int count ;
	String name="SUZUKI";
	
	Wheel x;
	FluffyDice y;
	Engine z;
	Car()
	{
System.out.println("Car name: "+ name);
	}
	
	Car(String name, Wheel x, FluffyDice y, Engine z)
	{
this.name=name;
this.x=x;
this.y=y;
this.z=z;

	}

}

