/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
class Engine
{
String enginee=" I am Engine";
	public String display()

	{
		System.out.println("Engine:"+ enginee);
		return null;
	}

}

