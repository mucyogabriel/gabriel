/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
class FluffyDice
{

	String color;
	FluffyDice(String color)
	{
		this.color=color;
	}
	public String display()
	{
		
		return null;
	}
	
}

