/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
import java.util.ArrayList;
class Wheel
{

	int count;
	int postion;
	Wheel()
	{

ArrayList <String> well=new ArrayList <String>();
{
well.add("I am a Wheel No: 20");
//System.out.println(".");
well.add("I am a Wheel No: 30");
//System.out.println(".");
well.add("I am a Wheel No: 40");
//System.out.println(".");
well.add("I am a Wheel No: 50");


for(int k=0; k<4; k ++)
{

	System.out.println(well);
}
//System.out.println(".");

}
	}
	public String display()
	{


		return null;

	}




}

