/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
import java.util.*;

class Car 
{
	String plateNumber;
	String manufactured;
	Car(String plateNumber, String manufactured)
	{
		
		this.plateNumber=plateNumber;
		this.manufactured=manufactured;
		System.out.println("PlateNumber: "+plateNumber);
		System.out.println("Manufactured: "+manufactured);
		System.out.println("===================");
	}
	public static void main(String[] args)
	{
		System.out.println("Car");
		Item tt=new Item("BMW","Utility",5000000.0);
		Car yy=new Car("RAB123B","Thu Jan 01 02:00:02 CAT 1970");
		
	}
}