/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author MUCYO {Gabriel}
Date January 25, 2021
*/
import java.util.*;

class Item
{
	String name;
	String category;
	double price;
	Item(String name, String category,double price)
	{
		this.name=name;
		this.category=category;
		this.price=price;
		System.out.println("Name: "+name);
		System.out.println("Category: "+category);
		System.out.println("Price: "+price);
	}
}