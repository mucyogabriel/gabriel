/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author {MUCYO Gabriel}
Date January 25, 2021
*/
import java.util.*;

class Controller
{
	public static void main(String[] args)
	{
		System.out.println("Property");
		Item i=new Item("House","Property",1000000.0);
		Property x=new Property(4,500,5);

		System.out.println("Car");
		Item j=new Item("BMW","Utility",5000000.0);
		Car y=new Car("RAB123B","Thu Jan 01 02:00:02 CAT 1970");

		System.out.println("Household");
		Item k=new Item("Flask","Utility",5000.0);
		Household z=new Household("Used","http.picture.com/flask");
		
	}
}