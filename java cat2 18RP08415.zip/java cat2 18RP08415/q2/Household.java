/*On my honor, as a Rwanda Poltechnic/ IPRC Tumba student, 
I have neither given nor  received unauthorized assistance on
this work.
@author MUCYO {Gabriel}
Date January 25, 2021
*/
import java.util.*;

class Household
{
	String condition;
	String picture;
	Household(String condition, String picture)
	{
		this.condition=condition;
		this.picture=picture;
		///System.out.println("Household");
		System.out.println("Name: "+condition);
		System.out.println("Category: "+picture);
	}
	public static void main(String[] args)
	{
		System.out.println("Household");
		Item tt=new Item("Flask","Utility",5000.0);
		Household yy=new Household("Used","http.picture.com/flask");
		
	}
}